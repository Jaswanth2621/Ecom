package com.springServer.ecom.modal;

public class itemDetails {
}
