export const Details = [
  {
    name: 'Phone XL',
    price: 18000,
    id: 101,
  },
  {
    name: 'Black_Shoes',
    price: 18999,
    id: 102,
  },
  {
    name: 'Samsung mini',
    price: 18000,
    id: 103,
  },
  {
    name: 'Shoes',
    price: 18999,
    id: 104,
  },
  {
    name: 'Diary of Young Girl',
    price: 20099,
    id: 105,
  },
  {
    name: 'Samsung',
    price: 19999,
    id: 106,
  },
  {
    name: 'Sony LED',
    price: 25000,
    id: 107,
  },
  {
    name: 'Diary of Young Girl',
    price: 20099,
    id: 108,
  },
  {
    name: 'Samsung',
    price: 19999,
    id: 109,
  },
  {
    name: 'Sony LED',
    price: 25000,
    id: 110,
  }
];
